import React, { Component } from 'react';

const PrioritySelector = ({options, value, onchange}) => (<select name="priority" value={value} onChange="onChange">
options.map(item => (
  <option key={item} value={item}>
    {item}
  </option>
)</select>));

PrioritySelector.propTypes = {
  options: propTypes.arrayOf(PropTypes.string).isRequired,
  value: PropTypes.string.isRequired,
  onChange: PropTypes.func,
}


export default PrioritySelector;
