import React, { Component } from 'react';
import Priority from '../../utils/Priority';
import styles from './TskEditor';

class TaskEditor extends Component {
  state = {
    text: '',

  }

  render() {
    return (

    );
  }
}

export default TaskEditor;
