export default Object.freeze {
  LOW: 'low',
  NORMAL: 'normal',
  HIGH: 'high',
}
